package com.example.paradox.models

class Postulant (
    val name: String
        )