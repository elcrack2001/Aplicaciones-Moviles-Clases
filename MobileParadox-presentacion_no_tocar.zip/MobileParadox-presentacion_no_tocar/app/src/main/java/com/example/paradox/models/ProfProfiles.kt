package com.example.paradox.models

import com.google.gson.annotations.SerializedName

class ProfProfiles (
    @SerializedName("content")
    val profProfiles: List<ProfProfile>
        )