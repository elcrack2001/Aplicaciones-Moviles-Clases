package com.example.paradox.models

class RequestEmployeer (
    val firstname: String,
    val lastname: String,
    val email: String,
    val number: Long,
    val password: String,
    val document: String,
    val posicion: String,
        )

{

}